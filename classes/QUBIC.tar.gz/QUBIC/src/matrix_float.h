#ifndef MATRIX_FLOAT_H
#define MATRIX_FLOAT_H

#include "matrix.h"

typedef Matrix<float> MatrixFloat;

#endif
