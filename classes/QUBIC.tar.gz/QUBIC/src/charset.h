#include <vector>

#include "edge_list.h"
DiscreteArrayListWithSymbols make_charsets_d(const DiscreteArrayList &arr, bool verbose);
